// JavaScript code for handling login, dashboard transition, and product display

// Selecting elements
const loginForm = document.getElementById('loginForm');
const loginContainer = document.getElementById('loginContainer');
const dashboardContainer = document.getElementById('dashboardContainer');
const productsContainer = document.getElementById('productsContainer');
const menuButton = document.getElementById('menuButton');
const menu = document.getElementById('menu');
const productsButton = document.getElementById('productsButton');

// Adding event listener to login form
loginForm.addEventListener('submit', function (e) {
    e.preventDefault(); // Prevent the form from submitting
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    // Simple validation (for demo purposes)
    if (email === '' || password === '') {
        alert('Please fill in both fields');
        return;
    }

    // Simulate successful login
    alert('Login successful!');

    // Hide the login page and show the dashboard
    loginContainer.style.display = 'none';
    dashboardContainer.style.display = 'flex';
});

// Toggle menu display
menuButton.addEventListener('click', function () {
    menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
});

// Show products when the Products button is clicked
productsButton.addEventListener('click', function () {
    dashboardContainer.style.display = 'none';
    productsContainer.style.display = 'flex';
});
// Add to cart functionality
document.querySelectorAll(".add-to-cart-btn").forEach(button => {
    button.addEventListener("click", function () {
        const productInfo = this.parentElement;
        const productName = productInfo.querySelector("h2").innerText;
        const productPrice = parseFloat(productInfo.querySelector("p").innerText.replace('Price: ', '').replace(' Rs', ''));

        const basketItems = document.getElementById("basket-items");
        const listItem = document.createElement("li");
        listItem.innerText = `${productName} - ${productPrice} Rs`;

        const removeButton = document.createElement("button");
        removeButton.innerText = "Remove";
        removeButton.style.marginLeft = "10px";
        listItem.appendChild(removeButton);
        basketItems.appendChild(listItem);

        let totalAmount = parseFloat(document.getElementById("total-amount").innerText);
        totalAmount += productPrice;
        document.getElementById("total-amount").innerText = totalAmount;

        removeButton.addEventListener("click", function () {
            totalAmount -= productPrice;
            document.getElementById("total-amount").innerText = totalAmount;
            basketItems.removeChild(listItem);
            if (basketItems.children.length === 0) {
                document.getElementById("basket").style.display = "none";
            }
        });

        document.getElementById("basket").style.display = "block";
    });
});

// Checkout button functionality
document.getElementById("checkout-btn").addEventListener("click", function () {
    document.getElementById("payment-page").style.display = "block";
    document.getElementById("amount").value = document.getElementById("total-amount").innerText; // Correctly set total amount
    document.getElementById("basket").style.display = "none";
});

// Payment form submission
document.getElementById("paymentForm").addEventListener("submit", function (e) {
    e.preventDefault();
    alert("oredr confim!");
    location.reload();
});
